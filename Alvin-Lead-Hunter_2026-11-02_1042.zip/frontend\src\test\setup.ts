import '@testing-library/jest-dom/vitest';
import { afterEach } from 'vitest';

// The leads list is cached at module level; start every test from empty.
// Imported lazily so that this setup file never loads the data hooks (and
// through them the API client) before a test file has registered its mocks.
afterEach(async () => {
  const { clearLeadsCache } = await import('../hooks/useData');
  clearLeadsCache();
});
